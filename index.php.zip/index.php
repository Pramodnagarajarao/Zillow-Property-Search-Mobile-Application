<?php 
//Fetch the values from the data in the URL at server side
   header("Access-Control-Allow-Origin: *");
 ?>
 <?php
   $street_address = $_GET['street_address'];
   $city_address = $_GET['city_address'];
   $state_address = $_GET['state_address'];

   $address_new = str_replace(" ","+",$street_address);
   $city_new = str_replace(" ","+",$city_address); 
   $state_new = str_replace("","+",$state_address);
   $zillowID = "zillowid";
   $url = "http://www.zillow.com/webservice/GetDeepSearchResults.htm?zws-id=".$zillowID."&address=".$address_new."&citystatezip=".$city_new."%2C+".$state_address."&rentzestimate=true";
   $xml = simplexml_load_file($url);

    if(isset($xml->response->results->result)){
    // First Variable : useCode
    if(isset($xml->response->results->result->useCode)){
           $var_useCode = (string) $xml->response->results->result->useCode; 
           // $var_useCode =  $var_useCode1;
    }
    else{
           $var_useCode = "-";
    }

    // Second Variable : yearBuilt
    if(isset($xml->response->results->result->yearBuilt)){
        $var_yearBuilt = (string) $xml->response->results->result->yearBuilt;
    }
    else{
          $var_yearBuilt = "-";  
    }
    // Third Variable : lotSizeSqFt
    if(isset($xml->response->results->result->lotSizeSqFt)){
        $var_lotSizeSqFt = (string) $xml->response->results->result->lotSizeSqFt." sq.ft";
    }
    else{
            $var_lotSizeSqFt = "-";
    }

    // Fourth variable : finishedSqFt
    if(isset($xml->response->results->result->finishedSqFt)){
        $var_finishedSqFt = $xml->response->results->result->finishedSqFt." sq.ft";
    }
    else{
           $var_finishedSqFt = "-";
    }
   

    //Fifth Variable : bathrooms
    if(isset($xml->response->results->result->bathrooms)){
         $var_bathrooms = (string) $xml->response->results->result->bathrooms;
        }
    else{
          $var_bathrooms = "-";  
        }

    // Sixth variable : bedrooms
    if(isset($xml->response->results->result->bedrooms)){
        $var_bedrooms = (string) $xml->response->results->result->bedrooms;
        }
    else
        {
        $var_bedrooms = "-";
        }
        
    // Seventh Variable : taxAssessmentYear
    if(isset($xml->response->results->result->taxAssessmentYear)){
          $var_taxAssessmentYear =(string) $xml->response->results->result->taxAssessmentYear;
        }
    else{
            $var_taxAssessmentYear = "-";
        }       
            
            // 8th variable : taxAssessment
        if(isset($xml->response->results->result->taxAssessment)){
           $var_taxAssessment = $xml->response->results->result->taxAssessment;
           $var_taxAssessment1 = number_format((float)$var_taxAssessment,2);
           $var_taxAssessment2 = "$".$var_taxAssessment1;

        }
        else{
            $var_taxAssessment2 = "-";
        }
        // 9th variable : lastSoldPrice
        if(isset($xml->response->results->result->lastSoldPrice)){
           $var_lastSoldPrice = $xml->response->results->result->lastSoldPrice;
           $var_lastSoldPrice1 = number_format((float)$var_lastSoldPrice,2);
           $var_lastSoldPrice2 = "$".$var_lastSoldPrice1;
        }
        else {
           $var_lastSoldPrice2 = "-";
        }


        // 10th variable : lastSoldDate
        if(isset($xml->response->results->result->lastSoldDate)){
          $var_lastSoldDate = $xml->response->results->result->lastSoldDate;
          date_default_timezone_set('America/Los_Angeles');
          $var_lastSoldDate_fm = date_create($var_lastSoldDate);
          $var_lastSoldDate_fm = date_format($var_lastSoldDate_fm,'d-M-Y');
        }
        else
        {
         $var_lastSoldDate_fm = "-";
        }

        // 11th variable : lastupdated
        if(isset($xml->response->results->result->zestimate->{'last-updated'})){
            $var_lastupdated_zestimate = $xml->response->results->result->zestimate->{'last-updated'};
            date_default_timezone_set('America/Los_Angeles');
            $var_lastupdated_zestimate = date_create($var_lastupdated_zestimate);
            $var_lastupdated_zestimate = date_format($var_lastupdated_zestimate,'d-M-Y'); 
        }
        else{
            $var_lastupdated_zestimate = "-";
        }

        // 12th variable : zestimate amount
        if($xml->response->results->result->zestimate->amount != "" && $xml->response->results->result->zestimate->amount != null){
            $var_lastupdated_amount_zestimate = $xml->response->results->result->zestimate->amount;
            $var_lastupdated_amount_zestimate1 = number_format((float)$var_lastupdated_amount_zestimate,2);
            $var_lastupdated_amount_zestimate2 = "$".$var_lastupdated_amount_zestimate1;       
        }
        else
        {
            $var_lastupdated_amount_zestimate2 = "-";
        }

        // 13th and 14th variable : zestimate->valuationRange->low
        if((!empty($xml->response->results->result->zestimate->valuationRange->low)) && (!empty($xml->response->results->result->zestimate->valuationRange->high))){
            $var_valuationRangelow = $xml->response->results->result->zestimate->valuationRange->low;    
            $var_valuationRangelow1 = number_format((float)$var_valuationRangelow,2);  
            $var_valuationRangehigh = $xml->response->results->result->zestimate->valuationRange->high; 
            $var_valuationRangehigh1 = number_format((float)$var_valuationRangehigh,2);
            $var_valuationRange = "$".$var_valuationRangelow1." - "."$".$var_valuationRangehigh1; 
        }
        else
        {
            $var_valuationRangelow1 = "-";
            $var_valuationRangehigh1 = "-";
            $var_valuationRange = "-";
        }

        // 15th variable : $xml->response->results->result->rentzestimate->{'last-updated'}
        if(isset($xml->response->results->result->rentzestimate->{'last-updated'})){
            $var_lastupdated_rentzestimate = $xml->response->results->result->rentzestimate->{'last-updated'};
            date_default_timezone_set('America/Los_Angeles');
            $var_lastupdated_rentzestimate = date_create($var_lastupdated_rentzestimate);
            $var_lastupdated_rentzestimate = date_format($var_lastupdated_rentzestimate,'d-M-Y');
        }
        else
        {
            $var_lastupdated_rentzestimate = "-";
        }


        // 16th variable : $xml->response->results->result->rentzestimate->amount
        if($xml->response->results->result->rentzestimate->amount != null && $xml->response->results->result->rentzestimate->amount != ""){
            $var_lastupdated_amount_rentzestimate = $xml->response->results->result->rentzestimate->amount;
            //$var_lastupdated_amount_rentzestimate_float = (float)$var_lastupdated_amount_rentzestimate;
            $var_lastupdated_amount_rentzestimate1 = number_format((float)$var_lastupdated_amount_rentzestimate,2);
            $var_lastupdated_amount_rentzestimate2 = "$".$var_lastupdated_amount_rentzestimate1;

        }
        else
        {
            $var_lastupdated_amount_rentzestimate2 = "-";
        }

        // 17th and 18th variable : 
        if((!empty($xml->response->results->result->rentzestimate->valuationRange->low)) && (!empty($xml->response->results->result->rentzestimate->valuationRange->high))
            ){
            $var_valuationRange_rentzestimatelow = $xml->response->results->result->rentzestimate->valuationRange->low;    
            $var_valuationRange_rentzestimatelow1 = number_format((float)$var_valuationRange_rentzestimatelow,2);

            $var_valuationRange_rentzestimatehigh = $xml->response->results->result->rentzestimate->valuationRange->high; 
            $var_valuationRange_rentzestimatehigh1 = number_format((float)$var_valuationRange_rentzestimatehigh,2);

            $var_valuationRange_rentzestimate = "$".$var_valuationRange_rentzestimatelow1." - "."$".$var_valuationRange_rentzestimatehigh1;  

        }
        else
        {
            $var_valuationRange_rentzestimate = "-";
        }

        // href and address on top of the table 
        if(isset($xml->response->results->result->links->homedetails)){
           $result_url =(string) $xml->response->results->result->links->homedetails;
        }
        else{
             $result_url = "-";
        }
        if(isset($xml->response->results->result->address->street,$xml->response->results->result->address->city,$xml->response->results->result->address->state,$xml->response->results->result->address->zipcode)){
          $street = (string) $xml->response->results->result->address->street;
          $city = (string) $xml->response->results->result->address->city;
          $state = (string) $xml->response->results->result->address->state;
          $zipcode = (string) $xml->response->results->result->address->zipcode;
          $latitude = (string) $xml->response->results->result->address->latitude;
          $longitude = (string) $xml->response->results->result->address->longitude;
         $var_address = " ".$xml->response->results->result->address->street.", ".$xml->response->results->result->address->city.", ".$xml->response->results->result->address->state."-".$xml->response->results->result->address->zipcode;
        }
        else{
             $var_address = "-";
        }

        //echo "<td>30 days overall change :</td>"; 
        if($xml->response->results->result->zestimate->valueChange != "" && $xml->response->results->result->zestimate->valueChange != null){
              $var_valueChange_zestimate = $xml->response->results->result->zestimate->valueChange;   
                if($var_valueChange_zestimate < 0 ){
                    $var_valueChange_zestimate_new = -1 * $var_valueChange_zestimate;
                    $var_valueChange_zestimate1 = number_format((float)$var_valueChange_zestimate_new,2);
                    $var_valueChange_zestimate2 = "$".$var_valueChange_zestimate1;
                    $var_valueChange_rentzestimate2_downarrow = "http://cs-server.usc.edu:45678/hw/hw6/down_r.gif";
                    $a1 = "-";
                    } 
                else if($var_valueChange_zestimate == 0){
                    $var_valueChange_zestimate1 = number_format((float)$var_valueChange_zestimate,2);
                    $var_valueChange_zestimate2 = "$".$var_valueChange_zestimate1;
                    $a1 = " ";
                    }
                else {
                     
                    $var_valueChange_zestimate1 = number_format((float)$var_valueChange_zestimate,2);
                    $var_valueChange_zestimate2 = "$".$var_valueChange_zestimate1;
                    $var_valueChange_rentzestimate2_downarrow = "http://cs-server.usc.edu:45678/hw/hw6/up_g.gif"; 
                    $a1 = "+";

                }  
            } 
            else{
                $var_valueChange_zestimate2 = "-"; 
                $a1 = "";
            }
        $imgn =  "http://cs-server.usc.edu:45678/hw/hw6/down_r.gif";
        $imgp =  "http://cs-server.usc.edu:45678/hw/hw6/up_g.gif"; 
        // if($var_valueChange_zestimate <0){
        //  $var_valueChange_rentzestimate2_downarrow = "http://cs-server.usc.edu:45678/hw/hw6/down_r.gif";
        // }else
        // {
        //  $var_valueChange_rentzestimate2_downarrow = "http://cs-server.usc.edu:45678/hw/hw6/up_g.gif";
        // }

        // if($var_valueChange_rentzestimate <0){
        //  $var_valueChange_rentzestimate2_uparrow = "http://cs-server.usc.edu:45678/hw/hw6/down_r.gif";
        // }else
        // {
        //  $var_valueChange_rentzestimate2_uparrow = "http://cs-server.usc.edu:45678/hw/hw6/up_g.gif";
        // }
        //echo "<td>30 Days Rent change :</td>";
        if($xml->response->results->result->rentzestimate->valueChange != "" && $xml->response->results->result->rentzestimate->valueChange != null){

                 $var_valueChange_rentzestimate =  $xml->response->results->result->rentzestimate->valueChange;    
               if($var_valueChange_rentzestimate < 0){
                  $var_valueChange_rentzestimate_new = -1 * $var_valueChange_rentzestimate;           
                  $var_valueChange_rentzestimate1 = number_format((float)$var_valueChange_rentzestimate_new,2);
                  $var_valueChange_rentzestimate2 = "$".$var_valueChange_rentzestimate1;
                  $var_valueChange_rentzestimate2_uparrow =  "http://cs-server.usc.edu:45678/hw/hw6/down_r.gif"; 
                  $b1 = "-";
               }
               else if($var_valueChange_rentzestimate == 0){           
                  $var_valueChange_rentzestimate1 = number_format((float)$var_valueChange_rentzestimate,2);
                  $var_valueChange_rentzestimate2 = "$".$var_valueChange_rentzestimate1;
                  $b1 = "";
                    }
               else{

                    $var_valueChange_rentzestimate1 = number_format((float)$var_valueChange_rentzestimate,2);
                    $var_valueChange_rentzestimate2 = "$".$var_valueChange_rentzestimate1;
                    $var_valueChange_rentzestimate2_uparrow =  "http://cs-server.usc.edu:45678/hw/hw6/up_g.gif";
                    $b1 = "+";
               }
              }
               else
                {
                  $var_valueChange_rentzestimate2 = "-";
                  $b1 = "";
             }

            if(isset($xml->response->results->result->zpid)){
              $var_zpid = $xml->response->results->result->zpid; 
             }
            else{
              $var_zpid = "-";
             }

              // http://www.zillow.com/webservice/GetChart.htm?zws-id=<ZWSID>&unit-type=percent&zpid=48749425&width=300&height=150
              // $url_zpid = "http://www.zillow.com/webservice/GetChart.htm?zws-id=".$zillowID."&unit-type=percent&zpid=".$var_zpid."&width=600&height=300";
              // $xml_zpid = simplexml_load_file($url_zpid);

              $charturl_one = "http://www.zillow.com/webservice/GetChart.htm?zws-id=X1-ZWz1b2lkv1jpjf_6frtk&unit-type=percent&zpid=".$var_zpid."&width=600&height=300&chartDuration=1year";
              $chartResult1 = simplexml_load_file($charturl_one);
              $chartResult1 = (string) $chartResult1->response->url;


              $charturl_two = "http://www.zillow.com/webservice/GetChart.htm?zws-id=X1-ZWz1b2lkv1jpjf_6frtk&unit-type=percent&zpid=".$var_zpid."&width=600&height=300&chartDuration=5years";
              $chartResult2 = simplexml_load_file(urlencode($charturl_two));
              $chartResult2 = (string) $chartResult2->response->url;

              $charturl_three = "http://www.zillow.com/webservice/GetChart.htm?zws-id=X1-ZWz1b2lkv1jpjf_6frtk&unit-type=percent&zpid=".$var_zpid."&width=600&height=300&chartDuration=10years";
              $chartResult3 = simplexml_load_file(urlencode($charturl_three));
              $chartResult3 = (string) $chartResult3->response->url;


     }
    else
    {

    }
    $input_valid = $xml->message->code;
    if ($input_valid == 0) { 
      $arr = array("result"=>[
    'homedetails' => $result_url,
    'street' => $street,
    'city' => $city,
    'state' => $state,
    'zipcode' => $zipcode,
    'latitude' => $latitude,
    'longitude' => $longitude,
    'useCode' => $var_useCode, 
    'lastSoldPrice' => $var_lastSoldPrice2,
    'yearBuilt' => $var_yearBuilt, 
    'lastSoldDate' => $var_lastSoldDate_fm,
    'lotSizeSqFt' => $var_lotSizeSqFt,
    'estimateLastUpdate' =>  $var_lastupdated_zestimate, 
    'estimateAmount' => $var_lastupdated_amount_zestimate2,
    'finishedSqFt' => $var_finishedSqFt,
    'estimateValueChangeSign' => $a1,
    'imgn' => $imgn,
    'imgp' => $imgp,
    'estimateValueChange' => $var_valueChange_zestimate2,
    'bathrooms' => $var_bathrooms, 
    'estimateValuationRangeLow' => $var_valuationRangelow1,
    'estimateValuationRangeHigh' => $var_valuationRangehigh1,
    'bedrooms' => $var_bedrooms,
    'restimateLastUpdate' => $var_lastupdated_rentzestimate,
    'restimateAmount' => $var_lastupdated_amount_rentzestimate2,
    'taxAssessmentYear' => $var_taxAssessmentYear,
    'restimateValueChangeSign' => $b1,
    'restimateValueChange' => $var_valueChange_rentzestimate2,
    'taxAssessment' => $var_taxAssessment2,
    'restimateValuationRangeLow' => $var_valuationRange_rentzestimatelow1,
    'restimateValuationRangeHigh' => $var_valuationRange_rentzestimatehigh1,
    'err_code' =>(string)0,
    ],"chart"=>[
    'year1' => $chartResult1,
    'years5' => $chartResult2,
    'years10' => $chartResult3]
    );
    }
    else {

               $arr =array("result"=>['err_code' =>(string)1]);
       }


   $json = json_encode($arr);
   //echo "JSON is \n";
   echo $json;

?>

